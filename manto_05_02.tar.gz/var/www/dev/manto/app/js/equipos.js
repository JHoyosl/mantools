define(['api','jquery','ko','moment','validate','boostrapDatePicker','bootstrap','ui','moment/locale/es',], function(api,$,ko,moment){
    
    return {
        

        //Se crea un modelo para control

        equiposModel: function(){
            // --  global cotrol---//
			self.equiposList = ko.observableArray();
            // --  global cotrol---//
          
			
			//----- OPTIONS ----------------- //
				
			// self.centrosList = ko.observableArray();
			// self.selectedCentro = ko.observable();
			
			// self.loadMaestros = function(){
				
                // api.ajaxCom("centros","getCentrosList",{},function(response){
                    
					// var tmpOpt = response.data.info;
					// var opciones = [];
					
					// for(var i = 0; i<tmpOpt.length; i++){
						
						// opciones.push(new api.OptList(tmpOpt[i]["ID"],tmpOpt[i]["DESCRIPCION"]));
						
					// }
					// self.centrosList(opciones);
                // });

            // }			
			//----- OPTIONS END ----------------//
            
			//---- GENERAL ---//
			
			self.eliminarEquipo = function(equipo){


				console.log(equipo);
			}

			self.loadEquiposTabla = function(){
				
				api.ajaxCom("equipos","getEquipos",{},function(response){
					
					console.log(response.data.message);
					if(!response.data.status){
							
						alert("Error cargando Información");
						return;
					}
					
					var table = response.data.message.info;

					self.equiposList(table);
					

				});
				
			}			
			
			self.goCrearEquipo = function(){

				api.target("crearEquipo");

			}
			//---- GENERAL END --//
			
        },
        initialize: function(){

        	
        	ko.applyBindings(new this.equiposModel(), document.getElementById("equiposModel"));   
			
			self.loadEquiposTabla();
			// self.loadMaestros();
			$('#fechaNac').datetimepicker({format: 'YYYY-MM-DD',locale: 'ru'});
        },

    }

})