define(['api','jquery','ko','moment','validate','boostrapDatePicker','bootstrap','ui','moment/locale/es',], function(api,$,ko,moment){
    
    return {
        

        //Se crea un modelo para control

        crearEquipoModel: function(){

        	// alert("hola");

        },
        initialize: function(){

        	
        	ko.applyBindings(new this.crearEquipoModel(), document.getElementById("crearEquipoModel"));   
			
			// self.loadEquiposTabla();
			// self.loadMaestros();
			// $('#fechaNac').datetimepicker({format: 'YYYY-MM-DD',locale: 'ru'});
        },

    }

})