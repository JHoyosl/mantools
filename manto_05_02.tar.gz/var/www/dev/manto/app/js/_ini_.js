
define(['api','jquery'], function(api,$){
    
	return {

		//Toma la url para determinar que acción tomar. Separa url, ruta y parámetros

	    initialize: function(){
	    	
	    	require(['index'], function(module){
				  
			  module.initialize(); 

			});
	    	
	    },
	}

});